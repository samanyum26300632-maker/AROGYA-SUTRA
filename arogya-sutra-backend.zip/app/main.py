from contextlib import asynccontextmanager
import structlog
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import text
from app.core.config import settings
from app.core.logging import configure_logging
from app.db.base import Base
from app.db.session import engine
from app.api.v1.router import api_router
import app.models
configure_logging(); log=structlog.get_logger()
@asynccontextmanager
async def lifespan(app:FastAPI):
    if settings.auto_create_tables:
        async with engine.begin() as conn: await conn.run_sync(Base.metadata.create_all)
    log.info("app_started",env=settings.env); yield; await engine.dispose()
app=FastAPI(title=settings.app_name,version="1.0.0",description="Offline-first rural healthcare coordination API for SIH26133",lifespan=lifespan)
app.add_middleware(CORSMiddleware,allow_origins=settings.cors_list,allow_credentials=True,allow_methods=["*"],allow_headers=["*"])
app.include_router(api_router,prefix="/api/v1")
@app.get("/health",tags=["Health"])
async def health():
    try:
        async with engine.connect() as conn: await conn.execute(text("SELECT 1"))
        db="ok"
    except Exception: db="error"
    return {"status":"ok" if db=="ok" else "degraded","app":settings.app_name,"database":db}
