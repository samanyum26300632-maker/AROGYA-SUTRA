from statistics import mean
class ForecastService:
    """Explainable prototype: weighted recent moving average; intentionally not black-box ML."""
    def forecast(self, quantity:float, consumptions:list[float]) -> dict:
        if not consumptions: return {"avg_daily":0.0,"days":None,"risk":"UNKNOWN","reasoning":"No consumption history; forecast unavailable."}
        recent=consumptions[-14:]; avg=mean(recent)
        days=(quantity/avg) if avg>0 else None
        risk="CRITICAL" if days is not None and days<7 else "HIGH" if days is not None and days<14 else "MEDIUM" if days is not None and days<30 else "LOW"
        return {"avg_daily":round(avg,2),"days":round(days,1) if days is not None else None,"risk":risk,"reasoning":f"Current stock {quantity:.1f}; mean consumption over last {len(recent)} observations {avg:.2f}/day; estimated stockout = stock / mean demand."}
