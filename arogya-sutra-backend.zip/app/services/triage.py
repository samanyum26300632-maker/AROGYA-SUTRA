from dataclasses import dataclass
from app.schemas.clinical import VitalsInput
@dataclass
class TriageDecision: score:int; urgency:str; action:str; reasons:list[str]
class TriageEngine:
    """Auditable rule engine. Replace implementation later without changing API contract."""
    def score(self, symptoms:list[str], danger_flags:list[str], vitals:VitalsInput|None) -> TriageDecision:
        score=0; reasons=[]; s={x.lower() for x in symptoms}; flags={x.lower() for x in danger_flags}
        for f in flags:
            if f in {"unconscious","seizure","severe bleeding","chest pain","difficulty breathing","pregnancy bleeding"}: score+=8; reasons.append(f"danger flag: {f}")
        if "chest pain" in s: score+=5; reasons.append("chest pain")
        if "breathlessness" in s or "difficulty breathing" in s: score+=5; reasons.append("breathing symptom")
        if "high fever" in s: score+=2; reasons.append("high fever")
        if vitals:
            if vitals.spo2 is not None and vitals.spo2 < 90: score+=8; reasons.append("SpO2 < 90%")
            elif vitals.spo2 is not None and vitals.spo2 < 94: score+=4; reasons.append("SpO2 < 94%")
            if vitals.systolic_bp is not None and (vitals.systolic_bp < 80 or vitals.systolic_bp >= 180): score+=6; reasons.append("critical systolic BP")
            if vitals.pulse is not None and (vitals.pulse < 45 or vitals.pulse > 130): score+=4; reasons.append("abnormal pulse")
            if vitals.temperature_c is not None and vitals.temperature_c >= 40: score+=4; reasons.append("temperature >= 40C")
            if vitals.respiratory_rate is not None and vitals.respiratory_rate >= 30: score+=5; reasons.append("respiratory rate >= 30")
        if score >= 10: return TriageDecision(score,"EMERGENCY","Immediate emergency referral / 108; stabilize per local protocol.",reasons)
        if score >= 6: return TriageDecision(score,"HIGH","Urgent same-day doctor/PHC review; consider higher-centre referral.",reasons)
        if score >= 3: return TriageDecision(score,"MEDIUM","PHC clinical review within 24 hours and safety-net advice.",reasons)
        return TriageDecision(score,"LOW","Routine PHC/self-care guidance with warning-sign instructions.",reasons)
