import re
class VoiceService:
    async def transcribe(self, audio:bytes, language:str) -> str:
        # TODO: replace with real ASR call. Natural fit: Bhashini for Indian government deployment; Whisper fallback.
        samples={"mr":"रुग्णाला तीन दिवसांपासून ताप आणि खोकला आहे. ऑक्सिजन 92 आहे.","hi":"मरीज को तीन दिन से बुखार और खांसी है। ऑक्सीजन 92 है।","en":"Patient has fever and cough for three days. Oxygen is 92."}
        return samples.get(language, samples["en"])
    def extract(self, text:str) -> dict:
        # TODO: replace with production NLP/LLM entity extraction plus confidence scores and human verification.
        low=text.lower(); symptoms=[]
        mapping={"fever":["fever","ताप","बुखार"],"cough":["cough","खोकला","खांसी"],"breathlessness":["breath","श्वास","सांस"]}
        for canonical, keys in mapping.items():
            if any(k in low for k in keys): symptoms.append(canonical)
        nums=[int(x) for x in re.findall(r"\b\d{2,3}\b", text)]
        spo2=next((n for n in nums if 70<=n<=100),None)
        return {"symptoms":symptoms,"patient_reported_vitals":{"spo2":spo2},"needs_human_verification":True}
