from datetime import datetime, date
from typing import Any
from pydantic import BaseModel, ConfigDict, Field

class ORMModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)
class HealthResponse(BaseModel): status:str; app:str; database:str
class Message(BaseModel): message:str
