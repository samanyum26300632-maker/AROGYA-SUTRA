from datetime import datetime
from typing import Any, Literal
from pydantic import BaseModel, Field
class SyncItem(BaseModel):
    entity_type: Literal["PATIENT","VISIT","VITALS","TRIAGE","REGISTER_PATIENT","BOOK_APPOINTMENT","UPDATE_VITALS","RECORD_FOLLOWUP"]
    client_id: str
    client_updated_at: datetime
    version: int = 1
    payload: dict[str, Any]
class SyncBatchRequest(BaseModel): client_batch_id:str; items:list[SyncItem]=Field(min_length=1,max_length=500)
class SyncItemResult(BaseModel): client_id:str; entity_type:str; server_id:str|None=None; status:str; version:int|None=None; message:str|None=None
class SyncBatchResponse(BaseModel): batch_id:str; client_batch_id:str; total:int; synced:int; conflicts:int; pending_review:int; results:list[SyncItemResult]
