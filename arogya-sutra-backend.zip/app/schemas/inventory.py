from datetime import date
from pydantic import BaseModel, Field
class ConsumptionCreate(BaseModel): inventory_id:str; consumed_on:date; quantity_consumed:float=Field(gt=0)
class AtRiskItem(BaseModel): inventory_id:str; phc_id:str; drug_name:str; quantity:float; avg_daily_consumption:float; days_until_stockout:float|None; risk_level:str; reasoning:str
