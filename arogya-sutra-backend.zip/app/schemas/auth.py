from pydantic import BaseModel, EmailStr
from app.schemas.common import ORMModel
class LoginRequest(BaseModel): email:EmailStr; password:str
class TokenPair(BaseModel): access_token:str; refresh_token:str; token_type:str="bearer"
class RefreshRequest(BaseModel): refresh_token:str
class UserOut(ORMModel): id:str; email:str; full_name:str; role:str; district_id:str|None=None; phc_id:str|None=None; village_id:str|None=None
class UserCreate(BaseModel): email:EmailStr; full_name:str; password:str; role:str; district_id:str|None=None; phc_id:str|None=None; village_id:str|None=None
