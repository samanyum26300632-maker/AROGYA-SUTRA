from datetime import datetime
from pydantic import BaseModel, Field
from app.schemas.common import ORMModel
class PatientCreate(BaseModel): client_id:str|None=None; name:str; age:int=Field(ge=0,le=120); gender:str; phone:str; village_id:str; abha_id:str|None=None; blood_group:str|None=None; allergies:list[str]=[]; chronic_conditions:list[str]=[]; is_high_risk:bool=False; high_risk_reason:str|None=None; client_updated_at:datetime|None=None; version:int=1
class PatientOut(ORMModel): id:str; client_id:str|None; name:str; age:int; gender:str; phone:str; village_id:str; is_high_risk:bool; sync_status:str; version:int; updated_at:datetime
class VisitCreate(BaseModel): client_id:str|None=None; patient_id:str; phc_id:str; chief_complaint:str=""; occurred_at:datetime|None=None; version:int=1
class VitalsInput(BaseModel): temperature_c:float|None=None; systolic_bp:int|None=None; diastolic_bp:int|None=None; pulse:int|None=None; spo2:int|None=None; respiratory_rate:int|None=None; weight_kg:float|None=None
class TriageCreate(BaseModel): client_id:str|None=None; visit_id:str; symptoms:list[str]=[]; danger_flags:list[str]=[]; vitals:VitalsInput|None=None
class TriageOut(ORMModel): id:str; visit_id:str; symptoms:list; danger_flags:list; score:int; suggested_urgency:str; suggested_action:str; doctor_urgency:str|None; doctor_notes:str|None; sync_status:str
class TriageReview(BaseModel): urgency:str|None=None; notes:str|None=None; prescription:dict|None=None
