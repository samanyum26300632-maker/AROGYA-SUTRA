from pydantic import BaseModel
class VoiceResult(BaseModel): id:str; language:str; transcript:str; structured_data:dict; asr_provider:str
