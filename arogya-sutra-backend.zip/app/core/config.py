from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "AROGYA-SUTRA API"
    env: str = "dev"
    secret_key: str = "change-me"
    access_token_minutes: int = 30
    refresh_token_days: int = 7
    database_url: str = "sqlite+aiosqlite:///./arogya_sutra.db"
    postgres_url: str = "postgresql+asyncpg://arogya:arogya@postgres:5432/arogya"
    redis_url: str = "redis://redis:6379/0"
    cors_origins: str = "http://localhost:3000,https://your-production-frontend.example"
    auto_create_tables: bool = True
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @property
    def cors_list(self) -> list[str]:
        return [x.strip() for x in self.cors_origins.split(",") if x.strip()]

@lru_cache
def get_settings() -> Settings:
    return Settings()

settings = get_settings()
