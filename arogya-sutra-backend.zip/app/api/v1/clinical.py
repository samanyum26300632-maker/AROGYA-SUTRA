from datetime import datetime, timezone
from fastapi import APIRouter,Depends,HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.session import get_db
from app.api.deps import current_user,require_roles
from app.models import Patient,Visit,VitalSigns,TriageAssessment,Role,SyncStatus
from app.schemas.clinical import PatientCreate,PatientOut,VisitCreate,TriageCreate,TriageOut,TriageReview
from app.services.triage import TriageEngine
router=APIRouter(prefix="/clinical",tags=["Clinical"]); engine=TriageEngine()
@router.post("/patients",response_model=PatientOut)
async def create_patient(data:PatientCreate,user=Depends(require_roles(Role.ASHA_WORKER.value,Role.ANM.value,Role.DOCTOR.value)),db:AsyncSession=Depends(get_db)):
    p=Patient(**data.model_dump(),created_by=user.id,sync_status=SyncStatus.SYNCED.value); db.add(p); await db.commit(); await db.refresh(p); return p
@router.get("/patients",response_model=list[PatientOut])
async def list_patients(user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    q=select(Patient)
    if user.role==Role.ASHA_WORKER.value and user.village_id: q=q.where(Patient.village_id==user.village_id)
    return list((await db.execute(q.order_by(Patient.updated_at.desc()))).scalars())
@router.post("/visits")
async def create_visit(data:VisitCreate,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    d=data.model_dump(exclude_none=True); v=Visit(**d,health_worker_id=user.id); db.add(v); await db.commit(); await db.refresh(v); return {"id":v.id,"sync_status":v.sync_status}
@router.post("/triage",response_model=TriageOut)
async def triage(data:TriageCreate,user=Depends(require_roles(Role.ASHA_WORKER.value,Role.ANM.value,Role.DOCTOR.value)),db:AsyncSession=Depends(get_db)):
    if not await db.get(Visit,data.visit_id): raise HTTPException(404,"Visit not found")
    decision=engine.score(data.symptoms,data.danger_flags,data.vitals)
    t=TriageAssessment(client_id=data.client_id,visit_id=data.visit_id,symptoms=data.symptoms,danger_flags=data.danger_flags,score=decision.score,suggested_urgency=decision.urgency,suggested_action=decision.action,sync_status=SyncStatus.PENDING_REVIEW.value); db.add(t)
    if data.vitals: db.add(VitalSigns(visit_id=data.visit_id,**data.vitals.model_dump(),sync_status=SyncStatus.PENDING_REVIEW.value))
    await db.commit(); await db.refresh(t); return t
@router.get("/triage/queue",response_model=list[TriageOut])
async def queue(user=Depends(require_roles(Role.DOCTOR.value,Role.PHC_ADMIN.value,Role.DISTRICT_ADMIN.value)),db:AsyncSession=Depends(get_db)):
    q=select(TriageAssessment).where(TriageAssessment.sync_status==SyncStatus.PENDING_REVIEW.value)
    return list((await db.execute(q.order_by(TriageAssessment.score.desc(),TriageAssessment.updated_at))).scalars())
@router.post("/triage/{triage_id}/review",response_model=TriageOut)
async def review(triage_id:str,data:TriageReview,user=Depends(require_roles(Role.DOCTOR.value)),db:AsyncSession=Depends(get_db)):
    t=await db.get(TriageAssessment,triage_id)
    if not t: raise HTTPException(404,"Triage not found")
    t.doctor_urgency=data.urgency or t.suggested_urgency; t.doctor_notes=data.notes; t.prescription=data.prescription; t.reviewed_by=user.id; t.reviewed_at=datetime.now(timezone.utc); t.sync_status=SyncStatus.SYNCED.value; t.version+=1; await db.commit(); await db.refresh(t); return t
