from fastapi import APIRouter
from app.api.v1 import auth,clinical,sync,voice,inventory,dashboard
api_router=APIRouter(); api_router.include_router(auth.router); api_router.include_router(clinical.router); api_router.include_router(sync.router); api_router.include_router(voice.router); api_router.include_router(inventory.router); api_router.include_router(dashboard.router)
