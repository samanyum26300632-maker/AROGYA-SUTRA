from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.session import get_db
from app.models import User, Role
from app.schemas.auth import LoginRequest, TokenPair, RefreshRequest, UserCreate, UserOut
from app.core.security import verify_password,hash_password,create_access_token,create_refresh_token,decode_token
from app.api.deps import current_user, require_roles
router=APIRouter(prefix="/auth",tags=["Auth"])
@router.post("/login",response_model=TokenPair)
async def login(data:LoginRequest,db:AsyncSession=Depends(get_db)):
    user=(await db.execute(select(User).where(User.email==data.email))).scalar_one_or_none()
    if not user or not verify_password(data.password,user.password_hash): raise HTTPException(401,"Invalid credentials")
    return TokenPair(access_token=create_access_token(user.id),refresh_token=create_refresh_token(user.id))
@router.post("/refresh",response_model=TokenPair)
async def refresh(data:RefreshRequest,db:AsyncSession=Depends(get_db)):
    try: uid=decode_token(data.refresh_token,"refresh")
    except ValueError: raise HTTPException(401,"Invalid refresh token")
    if not await db.get(User,uid): raise HTTPException(401,"Unknown user")
    return TokenPair(access_token=create_access_token(uid),refresh_token=create_refresh_token(uid))
@router.get("/me",response_model=UserOut)
async def me(user:User=Depends(current_user)): return user
@router.post("/users",response_model=UserOut)
async def provision(data:UserCreate,admin:User=Depends(require_roles(Role.PHC_ADMIN.value,Role.DISTRICT_ADMIN.value)),db:AsyncSession=Depends(get_db)):
    if (await db.execute(select(User).where(User.email==data.email))).scalar_one_or_none(): raise HTTPException(409,"Email exists")
    user=User(email=data.email,full_name=data.full_name,password_hash=hash_password(data.password),role=data.role,district_id=data.district_id,phc_id=data.phc_id,village_id=data.village_id); db.add(user); await db.commit(); await db.refresh(user); return user
