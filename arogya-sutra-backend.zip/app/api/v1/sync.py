from fastapi import APIRouter,Depends,HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.session import get_db
from app.api.deps import current_user
from app.models import Patient,Visit,VitalSigns,TriageAssessment,SyncBatch,SyncStatus
from app.schemas.sync import SyncBatchRequest,SyncBatchResponse,SyncItemResult
from app.services.triage import TriageEngine
router=APIRouter(prefix="/sync",tags=["Offline Sync"]); triage_engine=TriageEngine()
MAP={"REGISTER_PATIENT":"PATIENT","BOOK_APPOINTMENT":"VISIT","UPDATE_VITALS":"VITALS","RECORD_FOLLOWUP":"TRIAGE"}
async def existing(db,model,client_id): return (await db.execute(select(model).where(model.client_id==client_id))).scalar_one_or_none()
@router.post("/batch",response_model=SyncBatchResponse)
async def sync_batch(req:SyncBatchRequest,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    old=(await db.execute(select(SyncBatch).where(SyncBatch.client_batch_id==req.client_batch_id))).scalar_one_or_none()
    if old: return SyncBatchResponse(batch_id=old.id,client_batch_id=old.client_batch_id,total=old.total,synced=old.synced,conflicts=old.conflicts,pending_review=old.pending_review,results=old.results)
    results=[]; synced=conflicts=pending=0
    for item in req.items:
        typ=MAP.get(item.entity_type,item.entity_type); model={"PATIENT":Patient,"VISIT":Visit,"VITALS":VitalSigns,"TRIAGE":TriageAssessment}[typ]; obj=await existing(db,model,item.client_id)
        if obj and item.client_updated_at <= obj.updated_at:
            conflicts+=1; results.append(SyncItemResult(client_id=item.client_id,entity_type=typ,server_id=obj.id,status=SyncStatus.CONFLICT.value,version=obj.version,message="Server version is newer or equal (last-write-wins).")); continue
        payload=dict(item.payload); payload.pop("id",None); payload["client_id"]=item.client_id; payload["version"]=item.version; status=SyncStatus.PENDING_REVIEW.value if typ in {"VISIT","VITALS","TRIAGE"} else SyncStatus.SYNCED.value
        if typ=="PATIENT": payload.setdefault("created_by",user.id); payload["client_updated_at"]=item.client_updated_at
        if typ=="VISIT": payload.setdefault("health_worker_id",user.id)
        if typ=="TRIAGE":
            vitals=payload.pop("vitals",None); decision=triage_engine.score(payload.get("symptoms",[]),payload.get("danger_flags",[]),None); payload.update(score=decision.score,suggested_urgency=decision.urgency,suggested_action=decision.action)
        if obj:
            for k,v in payload.items():
                if hasattr(obj,k): setattr(obj,k,v)
            obj.version=max(obj.version+1,item.version); obj.sync_status=status
        else:
            obj=model(**payload,sync_status=status); db.add(obj); await db.flush()
        if status==SyncStatus.PENDING_REVIEW.value: pending+=1
        else: synced+=1
        results.append(SyncItemResult(client_id=item.client_id,entity_type=typ,server_id=obj.id,status=status,version=obj.version))
    batch=SyncBatch(client_batch_id=req.client_batch_id,user_id=user.id,total=len(req.items),synced=synced,conflicts=conflicts,pending_review=pending,results=[r.model_dump() for r in results]); db.add(batch); await db.commit(); await db.refresh(batch)
    return SyncBatchResponse(batch_id=batch.id,client_batch_id=batch.client_batch_id,total=batch.total,synced=synced,conflicts=conflicts,pending_review=pending,results=results)
@router.get("/batches/{client_batch_id}",response_model=SyncBatchResponse)
async def batch_status(client_batch_id:str,user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    b=(await db.execute(select(SyncBatch).where(SyncBatch.client_batch_id==client_batch_id,SyncBatch.user_id==user.id))).scalar_one_or_none()
    if not b: raise HTTPException(404,"Batch not found")
    return SyncBatchResponse(batch_id=b.id,client_batch_id=b.client_batch_id,total=b.total,synced=b.synced,conflicts=b.conflicts,pending_review=b.pending_review,results=b.results)
