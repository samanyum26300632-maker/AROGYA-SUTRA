from fastapi import APIRouter,Depends,BackgroundTasks,HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.api.deps import require_roles
from app.db.session import get_db
from app.models import DrugInventory,DrugConsumptionLog,Role
from app.schemas.inventory import ConsumptionCreate,AtRiskItem
from app.services.forecast import ForecastService
router=APIRouter(prefix="/inventory",tags=["Drug Supply"]); forecaster=ForecastService()
@router.post("/consumption")
async def log_consumption(data:ConsumptionCreate,bg:BackgroundTasks,user=Depends(require_roles(Role.PHC_ADMIN.value,Role.DISTRICT_ADMIN.value,Role.ANM.value)),db:AsyncSession=Depends(get_db)):
    inv=await db.get(DrugInventory,data.inventory_id)
    if not inv: raise HTTPException(404,"Inventory not found")
    db.add(DrugConsumptionLog(inventory_id=inv.id,consumed_on=data.consumed_on,quantity_consumed=data.quantity_consumed,created_by=user.id)); inv.quantity=max(0,inv.quantity-data.quantity_consumed); await db.commit(); return {"status":"logged","remaining_quantity":inv.quantity,"forecast_recompute":"computed on demand in prototype"}
@router.get("/at-risk",response_model=list[AtRiskItem])
async def at_risk(user=Depends(require_roles(Role.PHC_ADMIN.value,Role.DISTRICT_ADMIN.value)),db:AsyncSession=Depends(get_db)):
    inventories=list((await db.execute(select(DrugInventory))).scalars()); out=[]
    for inv in inventories:
        logs=list((await db.execute(select(DrugConsumptionLog.quantity_consumed).where(DrugConsumptionLog.inventory_id==inv.id).order_by(DrugConsumptionLog.consumed_on))).scalars()); f=forecaster.forecast(inv.quantity,logs)
        if f["risk"] in {"CRITICAL","HIGH","MEDIUM"}: out.append(AtRiskItem(inventory_id=inv.id,phc_id=inv.phc_id,drug_name=inv.drug_name,quantity=inv.quantity,avg_daily_consumption=f["avg_daily"],days_until_stockout=f["days"],risk_level=f["risk"],reasoning=f["reasoning"]))
    order={"CRITICAL":0,"HIGH":1,"MEDIUM":2,"LOW":3,"UNKNOWN":4}; return sorted(out,key=lambda x:(order[x.risk_level],x.days_until_stockout or 99999))
