from fastapi import APIRouter,Depends
from sqlalchemy import select,func
from sqlalchemy.ext.asyncio import AsyncSession
from app.api.deps import current_user
from app.db.session import get_db
from app.models import TriageAssessment,Patient,SyncBatch,DrugInventory,DrugConsumptionLog,User
from app.services.forecast import ForecastService
router=APIRouter(prefix="/dashboard",tags=["Dashboards"]); forecast=ForecastService()
@router.get("/summary")
async def summary(user=Depends(current_user),db:AsyncSession=Depends(get_db)):
    triage_rows=(await db.execute(select(TriageAssessment.suggested_urgency,func.count()).group_by(TriageAssessment.suggested_urgency))).all(); triage={k:v for k,v in triage_rows}
    pending=(await db.execute(select(func.coalesce(func.sum(SyncBatch.pending_review),0)))).scalar_one(); patients=(await db.execute(select(func.count(Patient.id)))).scalar_one(); workers=(await db.execute(select(func.count(User.id)).where(User.role.in_(["ASHA_WORKER","ANM"])))).scalar_one()
    risks={"CRITICAL":0,"HIGH":0,"MEDIUM":0,"LOW":0,"UNKNOWN":0}
    for inv in list((await db.execute(select(DrugInventory))).scalars()):
        logs=list((await db.execute(select(DrugConsumptionLog.quantity_consumed).where(DrugConsumptionLog.inventory_id==inv.id))).scalars()); risks[forecast.forecast(inv.quantity,logs)["risk"]]+=1
    return {"triage_queue_counts":triage,"sync_backlog_pending_review":pending,"registered_patients":patients,"health_workers":workers,"stockout_risk_summary":risks}
