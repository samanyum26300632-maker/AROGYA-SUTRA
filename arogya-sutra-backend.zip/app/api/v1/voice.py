from fastapi import APIRouter,Depends,UploadFile,File,Form
from sqlalchemy.ext.asyncio import AsyncSession
from app.api.deps import require_roles
from app.db.session import get_db
from app.models import VoiceEntry,Role
from app.schemas.voice import VoiceResult
from app.services.voice import VoiceService
router=APIRouter(prefix="/voice",tags=["Vernacular Voice"]); service=VoiceService()
@router.post("/transcribe",response_model=VoiceResult)
async def transcribe(audio:UploadFile=File(...),language:str=Form("mr"),patient_id:str|None=Form(None),user=Depends(require_roles(Role.ASHA_WORKER.value,Role.ANM.value,Role.DOCTOR.value)),db:AsyncSession=Depends(get_db)):
    data=await audio.read(); transcript=await service.transcribe(data,language); structured=service.extract(transcript); entry=VoiceEntry(user_id=user.id,patient_id=patient_id,language=language,filename=audio.filename or "audio",transcript=transcript,structured_data=structured,asr_provider="MOCK_ASR"); db.add(entry); await db.commit(); await db.refresh(entry); return VoiceResult(id=entry.id,language=entry.language,transcript=entry.transcript,structured_data=entry.structured_data,asr_provider=entry.asr_provider)
