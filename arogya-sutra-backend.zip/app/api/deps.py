from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.db.session import get_db
from app.core.security import decode_token
from app.models import User
bearer=HTTPBearer()
async def current_user(credentials:HTTPAuthorizationCredentials=Depends(bearer), db:AsyncSession=Depends(get_db)) -> User:
    try: uid=decode_token(credentials.credentials)
    except ValueError: raise HTTPException(status_code=401,detail="Invalid or expired token")
    user=await db.get(User,uid)
    if not user or not user.is_active: raise HTTPException(status_code=401,detail="Inactive user")
    return user
def require_roles(*roles):
    async def dep(user:User=Depends(current_user)):
        if user.role not in roles: raise HTTPException(status_code=403,detail="Insufficient role")
        return user
    return dep
