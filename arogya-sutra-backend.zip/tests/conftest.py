import os
os.environ["DATABASE_URL"]="sqlite+aiosqlite:///./test_arogya.db"
os.environ["AUTO_CREATE_TABLES"]="true"
