from app.core.security import hash_password,verify_password,create_access_token,decode_token
def test_password_and_jwt():
    h=hash_password("secret123"); assert verify_password("secret123",h); token=create_access_token("abc"); assert decode_token(token)=="abc"
