from app.services.forecast import ForecastService
def test_stockout_forecast():
    f=ForecastService().forecast(20,[5]*10); assert f["days"]==4.0 and f["risk"]=="CRITICAL"
