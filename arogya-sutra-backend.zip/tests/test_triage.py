from app.services.triage import TriageEngine
from app.schemas.clinical import VitalsInput
def test_emergency_low_spo2():
    d=TriageEngine().score(["breathlessness"],[],VitalsInput(spo2=84,respiratory_rate=32))
    assert d.urgency=="EMERGENCY" and d.score>=10
def test_low_risk():
    assert TriageEngine().score(["mild cough"],[],VitalsInput(spo2=98,pulse=78)).urgency=="LOW"
