import asyncio
from datetime import date,timedelta
from sqlalchemy import select
from app.db.base import Base
from app.db.session import engine,SessionLocal
from app.models import District,PHC,Village,User,Patient,Visit,TriageAssessment,DrugInventory,DrugConsumptionLog,Role
from app.core.security import hash_password
async def main():
    async with engine.begin() as c: await c.run_sync(Base.metadata.create_all)
    async with SessionLocal() as db:
        if (await db.execute(select(User))).first(): print("Seed already present"); return
        d=District(name="Gadchiroli"); db.add(d); await db.flush(); phc1=PHC(name="PHC Armori",district_id=d.id,taluka="Armori",address="Armori, Gadchiroli",lat=20.467,lng=79.982); phc2=PHC(name="PHC Kurkheda",district_id=d.id,taluka="Kurkheda",address="Kurkheda, Gadchiroli",lat=20.162,lng=80.168); db.add_all([phc1,phc2]); await db.flush(); v1=Village(name="Wadadha",district_id=d.id,phc_id=phc1.id); v2=Village(name="Deulgaon",district_id=d.id,phc_id=phc2.id); db.add_all([v1,v2]); await db.flush()
        pw=hash_password("Demo@123")
        users=[User(email="asha@demo.in",full_name="Sunita Pawar",password_hash=pw,role=Role.ASHA_WORKER.value,district_id=d.id,phc_id=phc1.id,village_id=v1.id),User(email="anm@demo.in",full_name="Meena Shinde",password_hash=pw,role=Role.ANM.value,district_id=d.id,phc_id=phc1.id),User(email="doctor@demo.in",full_name="Dr. Nikhil Deshmukh",password_hash=pw,role=Role.DOCTOR.value,district_id=d.id,phc_id=phc1.id),User(email="phcadmin@demo.in",full_name="PHC Administrator",password_hash=pw,role=Role.PHC_ADMIN.value,district_id=d.id,phc_id=phc1.id),User(email="district@demo.in",full_name="District Health Officer",password_hash=pw,role=Role.DISTRICT_ADMIN.value,district_id=d.id)]; db.add_all(users); await db.flush()
        p=Patient(name="Savitri Madavi",age=58,gender="Female",phone="9000000001",village_id=v1.id,chronic_conditions=["Hypertension"],is_high_risk=True,high_risk_reason="Uncontrolled BP",created_by=users[0].id); db.add(p); await db.flush(); visit=Visit(patient_id=p.id,phc_id=phc1.id,health_worker_id=users[0].id,chief_complaint="Breathlessness and fever"); db.add(visit); await db.flush(); db.add(TriageAssessment(visit_id=visit.id,symptoms=["breathlessness","high fever"],danger_flags=[],score=7,suggested_urgency="HIGH",suggested_action="Urgent same-day doctor review"))
        inv1=DrugInventory(phc_id=phc1.id,drug_name="Paracetamol 500mg",generic_name="Paracetamol",quantity=45,reorder_level=100); inv2=DrugInventory(phc_id=phc1.id,drug_name="Amlodipine 5mg",generic_name="Amlodipine",quantity=18,reorder_level=60); inv3=DrugInventory(phc_id=phc2.id,drug_name="ORS Sachet",generic_name="ORS",quantity=240,reorder_level=100); db.add_all([inv1,inv2,inv3]); await db.flush()
        for i in range(14):
            day=date.today()-timedelta(days=13-i); db.add_all([DrugConsumptionLog(inventory_id=inv1.id,consumed_on=day,quantity_consumed=9+(i%3),created_by=users[3].id),DrugConsumptionLog(inventory_id=inv2.id,consumed_on=day,quantity_consumed=3+(i%2),created_by=users[3].id),DrugConsumptionLog(inventory_id=inv3.id,consumed_on=day,quantity_consumed=4+(i%2),created_by=users[4].id)])
        await db.commit(); print("Seeded. Password for all demo users: Demo@123")
if __name__=="__main__": asyncio.run(main())
